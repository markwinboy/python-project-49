### Hexlet tests and linter status:
[![Actions Status](https://github.com/markwinboy/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/markwinboy/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/64ff6d5e82bc41fbc0f3/maintainability)](https://codeclimate.com/github/markwinboy/python-project-49/maintainability)

https://asciinema.org/a/jGzBtxi4iSB5ODHLzN9FyEfaR

https://asciinema.org/a/t8zpu9VSBMajzFDblGGRB6X3q
