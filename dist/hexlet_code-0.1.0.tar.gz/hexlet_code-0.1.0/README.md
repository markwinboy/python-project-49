### Hexlet tests and linter status:
[![Actions Status](https://github.com/markwinboy/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/markwinboy/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/64ff6d5e82bc41fbc0f3/maintainability)](https://codeclimate.com/github/markwinboy/python-project-49/maintainability)

### Result of the brain-even module 
<a href="https://asciinema.org/a/jGzBtxi4iSB5ODHLzN9FyEfaR" target="_blank"><img src="https://asciinema.org/a/jGzBtxi4iSB5ODHLzN9FyEfaR.svg" /></a>

### Result of the brain-calc module 
[![asciicast](https://asciinema.org/a/t8zpu9VSBMajzFDblGGRB6X3q.svg)](https://asciinema.org/a/t8zpu9VSBMajzFDblGGRB6X3q)

### Result of the brain-gcd module 
[![asciicast](https://asciinema.org/a/lRptXA3XG2aR0tlmrp1Yu5CJr.svg)](https://asciinema.org/a/lRptXA3XG2aR0tlmrp1Yu5CJr)

### Result of the brain-progression module 
[![asciicast](https://asciinema.org/a/sYwE5JNOd6Crcpb77kg29HKYX.svg)](https://asciinema.org/a/sYwE5JNOd6Crcpb77kg29HKYX)

### Result of the brain-prime module 
[![asciicast](https://asciinema.org/a/fKv9gto6RePJoH86I9Ud9OL5h.svg)](https://asciinema.org/a/fKv9gto6RePJoH86I9Ud9OL5h)
